# 1v1.lol TriggerBot
![image](https://user-images.githubusercontent.com/81310818/138934160-01d6002a-e7c1-44a9-b37e-bcd8e0f62617.png)
```
Afin d'utiliser mon triggerbot, vous devez activer le plein écran sur 1v1.lol sur votre naviguateur (quelque-soit ce dernier).
Vous n'aurez ensuite plus qu'à le lancer et à jouer au jeu, le cheat supporte absolument tous les naviguateurs, vu que ce n'est pas un critère, de même pour les armes.
De plus, comme j'ai mis plusieurs criters de couleurs, le triggerbot tire lorsque tous les skins passent devant la souris, même si ce dernier n'est pas rouge.
Le triggerbot supporte toutes les résolutions, vu que j'ai fait en sorte qu'il s'y adapte, et ce dernier ne prend presque aucune performances.
Il est conseillé d'équiper le skin de base, bleu, et de ne pas mettre d'accessoires tel qu'un chapeau.
```
> ## V  E  N  A  X
